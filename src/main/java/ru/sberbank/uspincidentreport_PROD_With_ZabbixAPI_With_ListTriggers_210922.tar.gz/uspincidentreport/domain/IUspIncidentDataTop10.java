package ru.sberbank.uspincidentreport.domain;

public interface IUspIncidentDataTop10 {

    String getHost();
    String getAffected_Item();
    Integer getCount_Inc();


}
