package ru.sberbank.uspincidentreport.domain;

public interface IUspIncidentDataTotalCount {

    String getHPC_Assignment();
    String getAffected_Item();
    Integer getCount_Inc();



}
