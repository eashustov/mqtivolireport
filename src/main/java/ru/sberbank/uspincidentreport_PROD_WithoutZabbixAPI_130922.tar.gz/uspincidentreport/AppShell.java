package ru.sberbank.uspincidentreport;

import com.vaadin.flow.component.page.AppShellConfigurator;
import com.vaadin.flow.component.page.Push;

@Push
public class AppShell implements AppShellConfigurator {
}
